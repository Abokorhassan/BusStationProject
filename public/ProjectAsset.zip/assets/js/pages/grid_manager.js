 $(document).ready(function() {
        $("#mycanvas").gridmanager({
            debug: 1
        });
    });