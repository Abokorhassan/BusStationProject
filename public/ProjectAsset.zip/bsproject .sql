-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2019 at 09:59 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bsproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `accidents`
--

CREATE TABLE `accidents` (
  `id` int(10) UNSIGNED NOT NULL,
  `acc_lat` decimal(10,7) NOT NULL,
  `acc_long` decimal(10,7) NOT NULL,
  `user_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `acc_num` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `accidents`
--

INSERT INTO `accidents` (`id`, `acc_lat`, `acc_long`, `user_id`, `route_id`, `station_id`, `bus_id`, `driver_id`, `created_at`, `updated_at`, `acc_num`) VALUES
(2, '543.0000000', '434.1341000', 2, 0, 1, 23, 38, '2019-05-23 12:04:49', '2019-05-23 14:48:53', 'Acc_02'),
(4, '99.0000000', '99.9000000', 2, 0, 1, 24, 34, '2019-05-23 14:49:46', '2019-05-23 14:51:27', 'Acc_01'),
(5, '24.0000000', '42.0000000', 2, 0, 1, 23, 38, '2019-05-23 14:50:38', '2019-05-23 14:50:38', 'Acc_03');

-- --------------------------------------------------------

--
-- Table structure for table `activations`
--

CREATE TABLE `activations` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activations`
--

INSERT INTO `activations` (`id`, `user_id`, `code`, `completed`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 1, '4LicCRvBrBYilHDS9M4IXwGNyTrCnWnN', 1, '2019-04-04 10:33:07', '2019-04-04 10:33:07', '2019-04-04 10:33:07'),
(2, 2, 't1blrJgWkUuNmKqT3WfJ0Iy7dn6DgHXZ', 1, '2019-04-04 10:47:53', '2019-04-04 10:35:06', '2019-04-04 10:47:53'),
(3, 5, 'viddEcKpDAFANzKQyZzURgkR0yeatZCG', 1, '2019-04-14 03:38:55', '2019-04-14 03:36:42', '2019-04-14 03:38:55'),
(4, 6, 'tqLReLKFOIW2wyeGmSmY7Ftw4bG8OZDU', 1, '2019-05-15 04:04:55', '2019-05-15 04:03:45', '2019-05-15 04:04:55'),
(5, 7, 'dhxNOBnhB3AAC0kT89n6JtdBM4JCyn4H', 1, '2019-05-15 05:38:37', '2019-05-15 05:19:43', '2019-05-15 05:38:37'),
(6, 7, 'jfjOtoCJDO1T9VJovOYqTuQvJ15W0bXw', 1, '2019-05-15 05:36:21', '2019-05-15 05:19:43', '2019-05-15 05:36:21'),
(7, 8, 'CIYg7Ca5vtjwBIsJt8RP8uMyqK4XYcCM', 1, '2019-05-18 15:14:57', '2019-05-18 15:04:53', '2019-05-18 15:14:57'),
(8, 8, '58TOnLfXXs3LwncNlSV57KCumCmmxKKJ', 1, '2019-05-18 15:15:23', '2019-05-18 15:04:53', '2019-05-18 15:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` int(11) DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `log_name`, `description`, `subject_id`, `subject_type`, `causer_id`, `causer_type`, `properties`, `created_at`, `updated_at`) VALUES
(1, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-04 10:34:40', '2019-04-04 10:34:40'),
(2, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-04 10:34:45', '2019-04-04 10:34:45'),
(3, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-04 10:36:47', '2019-04-04 10:36:47'),
(4, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-04 10:45:48', '2019-04-04 10:45:48'),
(5, 'abokor Elmi', 'User Updated by John Doe', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-04 10:47:54', '2019-04-04 10:47:54'),
(6, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-04 10:48:16', '2019-04-04 10:48:16'),
(7, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-04 10:48:28', '2019-04-04 10:48:28'),
(8, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-04 10:50:29', '2019-04-04 10:50:29'),
(9, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-04 10:52:07', '2019-04-04 10:52:07'),
(10, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-04 10:53:10', '2019-04-04 10:53:10'),
(11, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-04 10:53:48', '2019-04-04 10:53:48'),
(12, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-04 11:28:46', '2019-04-04 11:28:46'),
(13, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-04 11:28:46', '2019-04-04 11:28:46'),
(14, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-05 03:26:47', '2019-04-05 03:26:47'),
(15, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-05 03:26:54', '2019-04-05 03:26:54'),
(16, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 12:53:45', '2019-04-06 12:53:45'),
(17, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 12:55:11', '2019-04-06 12:55:11'),
(18, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-06 12:55:43', '2019-04-06 12:55:43'),
(19, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-06 12:55:47', '2019-04-06 12:55:47'),
(20, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 12:59:13', '2019-04-06 12:59:13'),
(21, 'raazi hassan', 'User deleted by John Doe', 3, 'App\\User', 3, 'App\\User', '[]', '2019-04-06 13:00:07', '2019-04-06 13:00:07'),
(22, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 13:01:58', '2019-04-06 13:01:58'),
(23, 'Robert Hamilton', 'Registered', 4, 'App\\User', 4, 'App\\User', '[]', '2019-04-06 13:02:31', '2019-04-06 13:02:31'),
(24, 'Robert Hamilton', 'LoggedOut', 4, 'App\\User', 4, 'App\\User', '[]', '2019-04-06 13:02:37', '2019-04-06 13:02:37'),
(25, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 13:03:32', '2019-04-06 13:03:32'),
(26, 'Robert Hamilton', 'User Updated by John Doe', 4, 'App\\User', 4, 'App\\User', '[]', '2019-04-06 13:08:23', '2019-04-06 13:08:23'),
(27, 'raazi hassan', 'User restored by John Doe', 3, 'App\\User', 3, 'App\\User', '[]', '2019-04-06 13:11:00', '2019-04-06 13:11:00'),
(28, 'raazi hassan', 'User deleted by John Doe', 3, 'App\\User', 3, 'App\\User', '[]', '2019-04-06 13:11:35', '2019-04-06 13:11:35'),
(29, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 14:46:19', '2019-04-06 14:46:19'),
(30, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 15:37:19', '2019-04-06 15:37:19'),
(31, 'Robert Hamilton', 'LoggedIn', 4, 'App\\User', 4, 'App\\User', '[]', '2019-04-06 15:38:14', '2019-04-06 15:38:14'),
(32, 'Robert Hamilton', 'LoggedOut', 4, 'App\\User', 4, 'App\\User', '[]', '2019-04-06 15:39:38', '2019-04-06 15:39:38'),
(33, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 15:40:36', '2019-04-06 15:40:36'),
(34, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 15:40:55', '2019-04-06 15:40:55'),
(35, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-06 16:35:42', '2019-04-06 16:35:42'),
(36, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-07 01:48:32', '2019-04-07 01:48:32'),
(37, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-07 01:56:49', '2019-04-07 01:56:49'),
(38, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 01:57:35', '2019-04-07 01:57:35'),
(39, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 01:57:44', '2019-04-07 01:57:44'),
(40, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 02:01:34', '2019-04-07 02:01:34'),
(41, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 02:01:48', '2019-04-07 02:01:48'),
(42, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 02:02:23', '2019-04-07 02:02:23'),
(43, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 02:03:02', '2019-04-07 02:03:02'),
(44, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-07 02:03:48', '2019-04-07 02:03:48'),
(45, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-07 02:04:03', '2019-04-07 02:04:03'),
(46, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-07 02:04:40', '2019-04-07 02:04:40'),
(47, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-07 02:05:18', '2019-04-07 02:05:18'),
(48, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 02:09:05', '2019-04-07 02:09:05'),
(49, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 02:10:52', '2019-04-07 02:10:52'),
(50, 'Robert Hamilton', 'LoggedIn', 4, 'App\\User', 4, 'App\\User', '[]', '2019-04-07 02:13:23', '2019-04-07 02:13:23'),
(51, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 04:45:51', '2019-04-07 04:45:51'),
(52, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 07:51:06', '2019-04-07 07:51:06'),
(53, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 10:05:27', '2019-04-07 10:05:27'),
(54, 'John Doe', 'User Updated by John Doe', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-07 12:19:27', '2019-04-07 12:19:27'),
(55, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-08 01:32:37', '2019-04-08 01:32:37'),
(56, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-08 16:29:12', '2019-04-08 16:29:12'),
(57, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-09 02:34:43', '2019-04-09 02:34:43'),
(58, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-09 14:27:07', '2019-04-09 14:27:07'),
(59, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-10 09:56:09', '2019-04-10 09:56:09'),
(60, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-10 14:53:14', '2019-04-10 14:53:14'),
(61, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-11 02:07:25', '2019-04-11 02:07:25'),
(62, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-11 02:48:50', '2019-04-11 02:48:50'),
(63, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-11 03:26:08', '2019-04-11 03:26:08'),
(64, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-11 03:26:22', '2019-04-11 03:26:22'),
(65, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-11 03:26:58', '2019-04-11 03:26:58'),
(66, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-11 03:27:39', '2019-04-11 03:27:39'),
(67, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-11 07:41:23', '2019-04-11 07:41:23'),
(68, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-11 11:21:32', '2019-04-11 11:21:32'),
(69, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-11 11:21:38', '2019-04-11 11:21:38'),
(70, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-11 11:22:08', '2019-04-11 11:22:08'),
(71, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-11 12:05:30', '2019-04-11 12:05:30'),
(72, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-11 12:05:56', '2019-04-11 12:05:56'),
(73, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-12 00:45:16', '2019-04-12 00:45:16'),
(74, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-12 10:37:11', '2019-04-12 10:37:11'),
(75, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 02:42:59', '2019-04-13 02:42:59'),
(76, 'John Doe', 'User Updated by John Doe', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 08:24:31', '2019-04-13 08:24:31'),
(77, 'John Doe', 'User Updated by John Doe', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 08:27:33', '2019-04-13 08:27:33'),
(78, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 08:27:53', '2019-04-13 08:27:53'),
(79, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-13 08:42:13', '2019-04-13 08:42:13'),
(80, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 11:10:11', '2019-04-13 11:10:11'),
(81, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 11:11:04', '2019-04-13 11:11:04'),
(82, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 11:12:14', '2019-04-13 11:12:14'),
(83, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 11:13:52', '2019-04-13 11:13:52'),
(84, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-13 11:14:35', '2019-04-13 11:14:35'),
(85, 'abokor Elmi', 'User Updated successfully', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-13 11:19:12', '2019-04-13 11:19:12'),
(86, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-13 17:13:40', '2019-04-13 17:13:40'),
(87, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-13 17:14:00', '2019-04-13 17:14:00'),
(88, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-13 17:14:12', '2019-04-13 17:14:12'),
(89, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 00:21:49', '2019-04-14 00:21:49'),
(90, 'Robert Hamilton', 'User deleted by John Doe', 4, 'App\\User', 4, 'App\\User', '[]', '2019-04-14 00:34:58', '2019-04-14 00:34:58'),
(91, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:34:08', '2019-04-14 03:34:08'),
(92, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:35:18', '2019-04-14 03:35:18'),
(93, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:37:57', '2019-04-14 03:37:57'),
(94, 'kaambul yusuf', 'User Updated by John Doe', 5, 'App\\User', 5, 'App\\User', '[]', '2019-04-14 03:38:55', '2019-04-14 03:38:55'),
(95, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:39:01', '2019-04-14 03:39:01'),
(96, 'kaambul yusuf', 'LoggedIn', 5, 'App\\User', 5, 'App\\User', '[]', '2019-04-14 03:39:34', '2019-04-14 03:39:34'),
(97, 'kaambul yusuf', 'LoggedOut', 5, 'App\\User', 5, 'App\\User', '[]', '2019-04-14 03:39:56', '2019-04-14 03:39:56'),
(98, 'kaambul yusuf', 'LoggedIn', 5, 'App\\User', 5, 'App\\User', '[]', '2019-04-14 03:40:10', '2019-04-14 03:40:10'),
(99, 'kaambul yusuf', 'LoggedOut', 5, 'App\\User', 5, 'App\\User', '[]', '2019-04-14 03:40:13', '2019-04-14 03:40:13'),
(100, 'kaambul yusuf', 'LoggedIn', 5, 'App\\User', 5, 'App\\User', '[]', '2019-04-14 03:40:40', '2019-04-14 03:40:40'),
(101, 'kaambul yusuf', 'LoggedOut', 5, 'App\\User', 5, 'App\\User', '[]', '2019-04-14 03:40:43', '2019-04-14 03:40:43'),
(102, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:41:00', '2019-04-14 03:41:00'),
(103, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:41:40', '2019-04-14 03:41:40'),
(104, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:44:40', '2019-04-14 03:44:40'),
(105, 'abokor Elmi', 'User Updated by John Doe', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-14 03:45:06', '2019-04-14 03:45:06'),
(106, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 03:45:19', '2019-04-14 03:45:19'),
(107, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-14 03:45:42', '2019-04-14 03:45:42'),
(108, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 04:14:28', '2019-04-14 04:14:28'),
(109, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 07:31:24', '2019-04-14 07:31:24'),
(110, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-14 16:16:55', '2019-04-14 16:16:55'),
(111, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-15 00:29:00', '2019-04-15 00:29:00'),
(112, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-15 03:53:58', '2019-04-15 03:53:58'),
(113, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-16 04:39:12', '2019-04-16 04:39:12'),
(114, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-04-16 04:39:22', '2019-04-16 04:39:22'),
(115, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-16 04:39:36', '2019-04-16 04:39:36'),
(116, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-17 04:35:57', '2019-04-17 04:35:57'),
(117, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-18 02:30:58', '2019-04-18 02:30:58'),
(118, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-18 14:47:31', '2019-04-18 14:47:31'),
(119, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-19 03:49:14', '2019-04-19 03:49:14'),
(120, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-20 10:30:07', '2019-04-20 10:30:07'),
(121, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-21 11:23:49', '2019-04-21 11:23:49'),
(122, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-23 08:25:27', '2019-04-23 08:25:27'),
(123, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-25 01:26:08', '2019-04-25 01:26:08'),
(124, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-26 03:40:43', '2019-04-26 03:40:43'),
(125, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-26 11:57:33', '2019-04-26 11:57:33'),
(126, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-26 16:48:11', '2019-04-26 16:48:11'),
(127, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-27 12:03:27', '2019-04-27 12:03:27'),
(128, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-28 02:40:04', '2019-04-28 02:40:04'),
(129, 'yusuf cabdi', 'New User Created by John Doe', 6, 'App\\User', 6, 'App\\User', '[]', '2019-04-28 03:10:32', '2019-04-28 03:10:32'),
(130, 'yusuf cabdi', 'User Updated by John Doe', 6, 'App\\User', 6, 'App\\User', '[]', '2019-04-28 03:22:28', '2019-04-28 03:22:28'),
(131, 'yusuf cabdi', 'User Updated by John Doe', 6, 'App\\User', 6, 'App\\User', '[]', '2019-04-28 03:27:19', '2019-04-28 03:27:19'),
(132, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-28 10:13:20', '2019-04-28 10:13:20'),
(133, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-04-30 12:06:18', '2019-04-30 12:06:18'),
(134, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-01 01:26:42', '2019-05-01 01:26:42'),
(135, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-01 15:30:01', '2019-05-01 15:30:01'),
(136, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-05 03:05:35', '2019-05-05 03:05:35'),
(137, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-05 11:15:02', '2019-05-05 11:15:02'),
(138, 'abokor Elmi', 'User Updated by John Doe', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-05 13:23:12', '2019-05-05 13:23:12'),
(139, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-05 21:30:25', '2019-05-05 21:30:25'),
(140, 'yusuf cabdi', 'User Updated by John Doe', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-05 21:34:23', '2019-05-05 21:34:23'),
(141, 'yusuf cabdi', 'User deleted by John Doe', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-05 23:31:32', '2019-05-05 23:31:32'),
(142, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-06 03:41:33', '2019-05-06 03:41:33'),
(143, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-06 10:35:14', '2019-05-06 10:35:14'),
(144, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-07 07:02:14', '2019-05-07 07:02:14'),
(145, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-07 10:43:33', '2019-05-07 10:43:33'),
(146, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-08 02:40:00', '2019-05-08 02:40:00'),
(147, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-09 10:15:55', '2019-05-09 10:15:55'),
(148, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-10 05:02:27', '2019-05-10 05:02:27'),
(149, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-10 10:09:04', '2019-05-10 10:09:04'),
(150, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-10 14:39:36', '2019-05-10 14:39:36'),
(151, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-11 03:43:46', '2019-05-11 03:43:46'),
(152, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-11 22:08:19', '2019-05-11 22:08:19'),
(153, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-12 13:09:52', '2019-05-12 13:09:52'),
(154, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-12 23:19:36', '2019-05-12 23:19:36'),
(155, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-13 02:49:33', '2019-05-13 02:49:33'),
(156, 'abokor Elmi', 'User Updated by John Doe', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-13 05:15:13', '2019-05-13 05:15:13'),
(157, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-13 10:04:37', '2019-05-13 10:04:37'),
(158, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-13 15:13:10', '2019-05-13 15:13:10'),
(159, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-13 23:41:17', '2019-05-13 23:41:17'),
(160, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-14 11:15:33', '2019-05-14 11:15:33'),
(161, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-14 17:20:51', '2019-05-14 17:20:51'),
(162, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-15 01:21:26', '2019-05-15 01:21:26'),
(163, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-15 01:21:33', '2019-05-15 01:21:33'),
(164, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-15 01:36:47', '2019-05-15 01:36:47'),
(165, 'yusuf cabdi', 'User restored by John Doe', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-15 04:04:01', '2019-05-15 04:04:01'),
(166, 'yusuf cabdi', 'User Updated by John Doe', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-15 04:04:55', '2019-05-15 04:04:55'),
(167, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-15 05:18:56', '2019-05-15 05:18:56'),
(168, 'yusuf cabdi', 'LoggedIn', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-15 05:26:33', '2019-05-15 05:26:33'),
(169, 'yusuf cabdi', 'LoggedOut', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-15 05:31:09', '2019-05-15 05:31:09'),
(170, 'yahye hassan', 'LoggedIn', 7, 'App\\User', 7, 'App\\User', '[]', '2019-05-15 05:36:41', '2019-05-15 05:36:41'),
(171, 'yahye hassan', 'User Updated by John Doe', 7, 'App\\User', 7, 'App\\User', '[]', '2019-05-15 05:38:37', '2019-05-15 05:38:37'),
(172, 'yahye hassan', 'LoggedOut', 7, 'App\\User', 7, 'App\\User', '[]', '2019-05-15 06:10:55', '2019-05-15 06:10:55'),
(173, 'kaambul yusuf', 'LoggedIn', 5, 'App\\User', 5, 'App\\User', '[]', '2019-05-15 06:11:59', '2019-05-15 06:11:59'),
(174, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-15 10:21:10', '2019-05-15 10:21:10'),
(175, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-15 10:21:24', '2019-05-15 10:21:24'),
(176, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-15 10:56:37', '2019-05-15 10:56:37'),
(177, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-15 10:56:37', '2019-05-15 10:56:37'),
(178, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-15 10:59:02', '2019-05-15 10:59:02'),
(179, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-15 14:18:35', '2019-05-15 14:18:35'),
(180, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-16 03:49:11', '2019-05-16 03:49:11'),
(181, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-16 06:14:57', '2019-05-16 06:14:57'),
(182, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-16 10:22:51', '2019-05-16 10:22:51'),
(183, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-16 10:43:09', '2019-05-16 10:43:09'),
(184, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-16 11:27:08', '2019-05-16 11:27:08'),
(185, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-16 11:28:47', '2019-05-16 11:28:47'),
(186, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-17 03:54:35', '2019-05-17 03:54:35'),
(187, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-17 05:06:59', '2019-05-17 05:06:59'),
(188, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-17 05:07:16', '2019-05-17 05:07:16'),
(189, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-17 10:42:58', '2019-05-17 10:42:58'),
(190, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-18 10:15:30', '2019-05-18 10:15:30'),
(191, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-18 14:42:11', '2019-05-18 14:42:11'),
(192, 'abokor Elmi', 'User Updated successfully', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-18 14:42:23', '2019-05-18 14:42:23'),
(193, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-18 14:56:29', '2019-05-18 14:56:29'),
(194, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-18 15:03:52', '2019-05-18 15:03:52'),
(195, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-18 15:07:19', '2019-05-18 15:07:19'),
(196, 'nasir nimcan', 'User Updated by John Doe', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-18 15:14:57', '2019-05-18 15:14:57'),
(197, 'nasir nimcan', 'User Updated by John Doe', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-18 15:15:23', '2019-05-18 15:15:23'),
(198, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-18 15:21:34', '2019-05-18 15:21:34'),
(199, 'nasir nimcan', 'LoggedIn', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-18 16:00:07', '2019-05-18 16:00:07'),
(200, 'nasir nimcan', 'User Updated successfully', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-18 16:01:51', '2019-05-18 16:01:51'),
(201, 'yusuf cabdi', 'LoggedIn', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-18 18:36:17', '2019-05-18 18:36:17'),
(202, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-18 18:37:39', '2019-05-18 18:37:39'),
(203, 'yusuf cabdi', 'User Updated successfully', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-18 18:43:36', '2019-05-18 18:43:36'),
(204, 'yusuf cabdi', 'User Updated successfully', 6, 'App\\User', 6, 'App\\User', '[]', '2019-05-18 18:43:54', '2019-05-18 18:43:54'),
(205, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-19 03:52:58', '2019-05-19 03:52:58'),
(206, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-19 03:53:34', '2019-05-19 03:53:34'),
(207, 'nasir nimcan', 'LoggedIn', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-19 03:56:46', '2019-05-19 03:56:46'),
(208, 'nasir nimcan', 'LoggedIn', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-19 13:34:40', '2019-05-19 13:34:40'),
(209, 'nasir nimcan', 'User Updated successfully', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-19 13:34:58', '2019-05-19 13:34:58'),
(210, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-19 13:38:28', '2019-05-19 13:38:28'),
(211, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-19 18:16:54', '2019-05-19 18:16:54'),
(212, 'nasir nimcan', 'LoggedIn', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-20 04:16:21', '2019-05-20 04:16:21'),
(213, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-20 04:26:09', '2019-05-20 04:26:09'),
(214, 'nasir nimcan', 'LoggedIn', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-20 10:12:58', '2019-05-20 10:12:58'),
(215, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-20 11:17:13', '2019-05-20 11:17:13'),
(216, 'nasir nimcan', 'LoggedOut', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-20 11:30:24', '2019-05-20 11:30:24'),
(217, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-20 11:30:38', '2019-05-20 11:30:38'),
(218, 'abokor Elmi', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-20 13:32:55', '2019-05-20 13:32:55'),
(219, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-20 13:33:10', '2019-05-20 13:33:10'),
(220, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-20 16:57:49', '2019-05-20 16:57:49'),
(221, 'abokor Elmi', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-21 03:58:52', '2019-05-21 03:58:52'),
(222, 'abokor Elmis', 'User Updated successfully', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-21 07:15:07', '2019-05-21 07:15:07'),
(223, 'abokor Elmis', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-21 07:36:22', '2019-05-21 07:36:22'),
(224, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-21 07:36:44', '2019-05-21 07:36:44'),
(225, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-21 08:02:54', '2019-05-21 08:02:54'),
(226, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-21 08:03:10', '2019-05-21 08:03:10'),
(227, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-21 14:37:38', '2019-05-21 14:37:38'),
(228, 'nasir nimcan', 'LoggedIn', 8, 'App\\User', 8, 'App\\User', '[]', '2019-05-22 03:29:27', '2019-05-22 03:29:27'),
(229, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-22 03:37:28', '2019-05-22 03:37:28'),
(230, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-22 12:53:38', '2019-05-22 12:53:38'),
(231, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-22 12:54:16', '2019-05-22 12:54:16'),
(232, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 03:45:40', '2019-05-23 03:45:40'),
(233, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-23 03:46:53', '2019-05-23 03:46:53'),
(234, 'abokor Elmis', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-23 03:47:29', '2019-05-23 03:47:29'),
(235, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 03:48:05', '2019-05-23 03:48:05'),
(236, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 04:58:37', '2019-05-23 04:58:37'),
(237, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-23 04:59:05', '2019-05-23 04:59:05'),
(238, 'abokor Elmis', 'LoggedOut', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-23 05:02:32', '2019-05-23 05:02:32'),
(239, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 05:03:14', '2019-05-23 05:03:14'),
(240, 'John Doe', 'LoggedOut', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 05:07:38', '2019-05-23 05:07:38'),
(241, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-23 05:07:52', '2019-05-23 05:07:52'),
(242, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 07:05:01', '2019-05-23 07:05:01'),
(243, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 10:44:38', '2019-05-23 10:44:38'),
(244, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-23 10:45:42', '2019-05-23 10:45:42'),
(245, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-23 14:08:21', '2019-05-23 14:08:21'),
(246, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-23 14:08:43', '2019-05-23 14:08:43'),
(247, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-26 07:20:17', '2019-05-26 07:20:17'),
(248, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-26 10:37:18', '2019-05-26 10:37:18'),
(249, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-26 15:03:22', '2019-05-26 15:03:22'),
(250, 'abokor Elmis', 'LoggedIn', 2, 'App\\User', 2, 'App\\User', '[]', '2019-05-26 19:18:57', '2019-05-26 19:18:57'),
(251, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-27 07:02:54', '2019-05-27 07:02:54'),
(252, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-27 14:12:45', '2019-05-27 14:12:45'),
(253, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-28 14:13:46', '2019-05-28 14:13:46'),
(254, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-28 17:51:21', '2019-05-28 17:51:21'),
(255, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-28 22:14:26', '2019-05-28 22:14:26'),
(256, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-29 03:41:43', '2019-05-29 03:41:43'),
(257, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-29 13:11:54', '2019-05-29 13:11:54'),
(258, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-30 05:08:57', '2019-05-30 05:08:57'),
(259, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-30 11:10:15', '2019-05-30 11:10:15'),
(260, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-05-31 11:55:05', '2019-05-31 11:55:05'),
(261, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-06-01 03:24:58', '2019-06-01 03:24:58'),
(262, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-06-01 07:14:34', '2019-06-01 07:14:34'),
(263, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-06-01 12:02:52', '2019-06-01 12:02:52'),
(264, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-06-01 18:23:57', '2019-06-01 18:23:57'),
(265, 'John Doe', 'LoggedIn', 1, 'App\\User', 1, 'App\\User', '[]', '2019-06-02 04:21:27', '2019-06-02 04:21:27');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `blog_category_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `blog_category_id`, `user_id`, `title`, `slug`, `content`, `image`, `views`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, 'first blog', 'first-blog', '<p>i dont know what im writng</p>\n', NULL, 0, '2019-05-12 15:59:30', '2019-05-12 15:59:30', NULL),
(2, 1, 1, 'second blog', 'second-blog', '<p>ajdfkajdk</p>\n', NULL, 1, '2019-05-12 16:01:47', '2019-05-22 05:29:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'blog1', '2019-05-12 15:58:14', '2019-05-12 15:58:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `blog_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bus_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Driver_id` int(11) DEFAULT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  `schedual_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `number_seats` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`id`, `model_type`, `bus_number`, `Driver_id`, `station_id`, `user_id`, `route_id`, `schedual_id`, `created_at`, `updated_at`, `number_seats`) VALUES
(2, 'Nissan', 'bus_07', 3, 3, 8, NULL, NULL, '2019-04-23 08:45:20', '2019-05-19 15:44:46', 0),
(3, 'Ferari04', 'Bus_04', 32, 3, 5, NULL, NULL, '2019-04-30 13:28:20', '2019-05-11 16:45:20', 0),
(11, 'djakdj', 'ajf4f4', 33, 2, 6, NULL, NULL, '2019-05-15 03:31:56', '2019-05-18 15:59:09', 0),
(13, 'jfak', 'busjf43r', 35, 2, 6, NULL, NULL, '2019-05-18 18:42:55', '2019-05-18 18:42:55', 0),
(23, 'adjk', 'jakd', 38, 1, 2, NULL, NULL, '2019-05-22 17:19:59', '2019-05-29 10:57:09', 2),
(24, 'ajkaj', 'adjkj', 34, 1, 2, NULL, NULL, '2019-05-23 14:23:14', '2019-05-23 14:23:14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `busstops`
--

CREATE TABLE `busstops` (
  `id` int(10) UNSIGNED NOT NULL,
  `bstop_num` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` decimal(10,7) NOT NULL,
  `long` decimal(10,7) NOT NULL,
  `user_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `busstops`
--

INSERT INTO `busstops` (`id`, `bstop_num`, `name`, `lat`, `long`, `user_id`, `route_id`, `station_id`, `created_at`, `updated_at`) VALUES
(1, 'Bsp_01', 'edna Ad', '453.3530000', '554.4500000', 2, 0, 1, '2019-05-11 22:50:18', '2019-05-23 07:54:41'),
(3, 'Bsp_02', 'shimbirta', '357.3500000', '353.3500000', 2, 0, 1, '2019-05-23 07:59:08', '2019-05-23 07:59:08');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `sortname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `datatables`
--

CREATE TABLE `datatables` (
  `id` int(10) UNSIGNED NOT NULL,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `job` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sale_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `third_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date DEFAULT NULL,
  `pic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ph_number` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `driver_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`id`, `first_name`, `last_name`, `third_name`, `email`, `gender`, `dob`, `pic`, `address`, `license_number`, `ph_number`, `created_at`, `updated_at`, `station_id`, `user_id`, `driver_number`) VALUES
(3, 'Robert', 'afda', 'ada', 'xofelezu@pachilly.com', 'male', '2019-04-18', 'IMG_029_1557140508.jpeg', 'MS 39213', 'gt4', 5257835, '2019-05-06 07:56:52', '2019-05-15 03:26:43', 3, 8, 'Dr_05'),
(32, 'afa', 'djfka', 'djkaj', 'ajdkf@jfsk.com', 'male', NULL, NULL, NULL, 'fjkhj45', 2352612, '2019-05-11 14:31:19', '2019-05-15 03:27:00', 3, 5, 'Dr_11'),
(33, 'ajkfjg', 'ksjgksj', 'jgskfjs', 'adj@ajfk.com', 'male', NULL, NULL, NULL, 'jdkjf4', 4524524, '2019-05-11 14:52:25', '2019-05-11 14:52:25', 2, 6, 'Dr_02'),
(34, 'djafkj', 'hjh', 'djkafj', 'kajd@ajf.com', 'female', NULL, NULL, NULL, 'j4tk4j', 5345335, '2019-05-11 15:11:18', '2019-05-11 15:11:18', 1, 7, 'Dr_01'),
(35, 'nasir', 'nimcan', 'jamac', 'nasir@gmail.com', 'male', NULL, NULL, NULL, '44g4r', 4323743, '2019-05-18 18:40:31', '2019-05-18 18:40:31', 2, 1, 'Dr_05'),
(38, 'adk', 'adk', 'adk', 'ajd@gmail.com', 'male', NULL, NULL, NULL, 'djfk34', 5487538, '2019-05-22 17:11:33', '2019-05-22 17:11:33', 1, 2, 'Dr_04');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(10) UNSIGNED NOT NULL,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0000_00_00_000000_create_taggable_table', 1),
(2, '2014_07_02_230147_migration_cartalyst_sentinel', 1),
(3, '2014_10_04_174350_soft_delete_users', 1),
(4, '2014_12_10_011106_add_fields_to_user_table', 1),
(5, '2015_08_09_200015_create_blog_module_table', 1),
(6, '2015_08_11_064636_add_slug_to_blogs_table', 1),
(7, '2015_11_10_140011_create_files_table', 1),
(8, '2016_01_02_062647_create_tasks_table', 1),
(9, '2016_04_26_054601_create_datatables_table', 1),
(10, '2016_10_04_103149_add_fields_datatables_table', 1),
(11, '2017_09_29_113930_create_activity_log_table', 1),
(12, '2017_10_07_070138_create_countries_table', 1),
(13, '2017_10_24_130059_add_country_field', 1),
(14, '2018_02_14_072522_create_news_table', 1),
(15, '2019_04_07_064550_create_tests_table', 2),
(16, '2019_04_12_192221_create_stations_table', 3),
(17, '2019_04_14_055057_add_user_id_to_tests', 4),
(18, '2019_04_14_072038_create_buses_table', 5),
(19, '2019_04_15_090855_create_drivers_table', 6),
(20, '2019_04_20_132213_create_riders_table', 7),
(21, '2019_04_25_044548_create_reserves_table', 8),
(22, '2019_04_25_073720_create_busstops_table', 9),
(23, '2019_04_26_060931_create_accidents_table', 10),
(24, '2019_05_06_113230_modify_user_id_column_to_accespt_null', 11),
(25, '2019_05_06_133020_modify_driver__id_column_to_accespt_null', 12),
(26, '2019_05_08_080347_remove_fields_from_reserve_table', 13),
(27, '2019_05_08_082227_remove_some_fields_from_reserve_table', 14),
(28, '2019_05_10_173233_remove_id_number_from_reservation', 15),
(29, '2019_05_10_174106_add_rider_id_to_reserve', 16),
(30, '2019_05_11_065239_add_somefields_to_rider_model', 17),
(31, '2019_05_11_085759_add_somefields_to_driver_model', 18),
(32, '2019_05_11_165901_adding_driver_number_to_drivers', 19),
(33, '2019_05_11_173941_changing_driver_number_from_integer_to_string', 20),
(34, '2019_05_13_073151_add_station_id_to_users_table', 21),
(35, '2019_05_23_140649_add_acc_num_to_accidents', 22),
(36, '2019_05_26_101832_create_schedules_table', 23),
(37, '2019_05_26_103010_add_fields_schedules_table', 24),
(38, '2019_05_26_175154_remove_schedule_id_from_schedule_table', 25),
(39, '2019_05_26_191514_create_queues_table', 26),
(40, '2019_05_26_211209_remove_wrong_spelled_schedule_id', 27),
(41, '2019_05_28_172856_create_seats_table', 28),
(42, '2019_05_28_181721_add_bus_id_to_the_seat_table', 29),
(43, '2019_05_29_065424_add_number_of_seat_to_the_buses_table', 30),
(44, '2019_05_29_071018_rename_number_of_buses_to_number_of_seats_in_the_buses_table', 31),
(45, '2019_05_29_162819_add_some_fields_to_reserve_table', 32),
(46, '2019_05_29_180258_removing_bus_id_from_reserve_table', 33),
(47, '2019_05_29_182007_removing_schedule_id_from_schedule_table', 34),
(48, '2019_05_30_091530_adding_bus_number_to_queues_table', 35);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `image`, `category`, `created_at`, `updated_at`) VALUES
(1, 'a', '<p>fdajfdja</p>\n', 'PYHPapKbPJ.jpeg', 'world', '2019-05-05 04:34:32', '2019-05-05 04:34:32'),
(2, 'jkjkl', '<p>hjhkj</p>\n', 'Pz0shOJBD3.jpeg', 'sports', '2019-05-05 17:15:15', '2019-05-05 17:15:15');

-- --------------------------------------------------------

--
-- Table structure for table `persistences`
--

CREATE TABLE `persistences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `persistences`
--

INSERT INTO `persistences` (`id`, `user_id`, `code`, `created_at`, `updated_at`) VALUES
(2, 1, 'wlgUzPdl5rDxFogsFhU5qHEbdHrSf1PR', '2019-04-04 10:36:47', '2019-04-04 10:36:47'),
(8, 1, 'gNaAig6TWkwAnCUcYuoCj12YL48YRL0C', '2019-04-06 15:37:19', '2019-04-06 15:37:19'),
(11, 1, 'revX9Oso9wJz52TFxvezbxy33pfxmDqT', '2019-04-06 16:35:41', '2019-04-06 16:35:41'),
(19, 4, 'SEBDXz4xupcusYXTfada5U8IorPVvDV9', '2019-04-07 02:13:23', '2019-04-07 02:13:23'),
(20, 1, 'JVIHpzLDQQPIj8TDwDiECHXUBVVdLGqs', '2019-04-07 04:45:51', '2019-04-07 04:45:51'),
(21, 1, 'bXdtq2vw3QdTYXKvFdzKIKk97AdzCLVN', '2019-04-07 07:51:05', '2019-04-07 07:51:05'),
(22, 1, 'GgmHM8z9k0ncU35Vzw8MRSNJREJpTakj', '2019-04-07 10:05:26', '2019-04-07 10:05:26'),
(23, 1, 'r7lWB5Awq1gbSuD4nIpxpk9nICfgBurg', '2019-04-08 01:32:36', '2019-04-08 01:32:36'),
(24, 1, 'tpNlTEvKWgvGEFxvPGNRjdNMceVQcTIx', '2019-04-08 16:29:11', '2019-04-08 16:29:11'),
(25, 1, '10udh0i8fhxJVSqhp9wWSPS777zMbHKI', '2019-04-09 02:34:41', '2019-04-09 02:34:41'),
(26, 1, '4R9cM5NNj7IhsPRNQeSJBQXMpYgJRCrm', '2019-04-09 14:27:06', '2019-04-09 14:27:06'),
(27, 1, 'LkFuUixzHwlfJRPLPyoc0pa4beKTp43J', '2019-04-10 09:56:08', '2019-04-10 09:56:08'),
(28, 1, 'PLsW4sWxXxSkfcZgBjE2XH6Uq6KsIzVq', '2019-04-10 14:53:13', '2019-04-10 14:53:13'),
(29, 2, '4WLebYyk2WiIJO95QnuqbHINt8ytyJqA', '2019-04-11 02:07:24', '2019-04-11 02:07:24'),
(32, 1, 'Ct49tLaHLBBeKnEjTa4VdZvlGf2meW4H', '2019-04-11 03:27:38', '2019-04-11 03:27:38'),
(33, 1, '5LbeYvoqF86wQ8g7pMxqdLhOo9aOVzPY', '2019-04-11 07:41:23', '2019-04-11 07:41:23'),
(36, 2, '7iy261JxDzLd8KBq423ocwzR3qwq9GIT', '2019-04-11 12:05:55', '2019-04-11 12:05:55'),
(37, 2, 'CwrEHtl6wmgrodNWqczdrDpxQg5N95f2', '2019-04-12 00:45:16', '2019-04-12 00:45:16'),
(38, 2, 'Ca7ppJ4Dw2trRLAxm96RWl9mLMJx8spy', '2019-04-12 10:37:10', '2019-04-12 10:37:10'),
(40, 2, 'uIyP0i0kXodXHxLVLYkhgcaJvvLPjXm9', '2019-04-13 08:42:13', '2019-04-13 08:42:13'),
(43, 2, 'TCiLVYrxDvIoj236easmvNRCa8Txgc9R', '2019-04-13 11:14:35', '2019-04-13 11:14:35'),
(45, 1, 'cq53u5j6zX3wDdly2b7VE2SRnMR782f8', '2019-04-13 17:14:12', '2019-04-13 17:14:12'),
(46, 1, 'mpfmvl0818cT7ZIKrrwzfIJFngfo1Hcm', '2019-04-14 00:21:48', '2019-04-14 00:21:48'),
(54, 2, 'QlgJSSxF7GCrGf9h9aaFLOSJulF9ASnG', '2019-04-14 03:45:42', '2019-04-14 03:45:42'),
(55, 1, 'lfKqpdVikJ2vuXCeTTiXCBNS5kyQk2GS', '2019-04-14 04:14:27', '2019-04-14 04:14:27'),
(56, 1, '1bsJN5cD27MA7qTFOnM7TS1megIzPwPs', '2019-04-14 07:31:23', '2019-04-14 07:31:23'),
(57, 1, 'Binh4msa0UCEM9yBDqcjlyjLSHtBh7b0', '2019-04-14 16:16:53', '2019-04-14 16:16:53'),
(58, 1, 'UVTeFuaDrcIoc5IHrCAtI0lExGhrCfcw', '2019-04-15 00:28:59', '2019-04-15 00:28:59'),
(59, 1, 'GLFUREQwss5S4V14RrkTRNWoxdmoaPy7', '2019-04-15 03:53:57', '2019-04-15 03:53:57'),
(61, 1, 'jxa2i4YWEbktPXKcc00z2egVzPQniInN', '2019-04-16 04:39:36', '2019-04-16 04:39:36'),
(62, 1, 'n7yNQaxjwoL70MNkU5OeZfrN8YNdRRiQ', '2019-04-17 04:35:56', '2019-04-17 04:35:56'),
(63, 1, 'SmxyPcrOBlBGbY9oYwvqTpN7dMNdLSAK', '2019-04-18 02:30:54', '2019-04-18 02:30:54'),
(64, 1, 'nZwpT1JrPmcSJfciQ6AQjjKE3xuHUgys', '2019-04-18 14:47:30', '2019-04-18 14:47:30'),
(65, 1, '0KNtLgMwEEqJDDsmdzfIEp34AneVBuCc', '2019-04-19 03:49:13', '2019-04-19 03:49:13'),
(66, 1, 'dv0b1eCBK9G9FaUtEewriGEgLBEespto', '2019-04-20 10:30:05', '2019-04-20 10:30:05'),
(67, 1, 'Bf4nZ1uhPOaq1u6ziqNwYIoDpL9EaUod', '2019-04-21 11:23:48', '2019-04-21 11:23:48'),
(68, 1, '9m028PYTeruc6XAlEENFZIavfcbV0kJd', '2019-04-23 08:25:25', '2019-04-23 08:25:25'),
(69, 1, 'eOxobTAQYV5nyNKJDvGWwjMknIZZqXlp', '2019-04-25 01:25:55', '2019-04-25 01:25:55'),
(70, 1, '7Td4EEW7n4LpfIzigH8PloNhngme2yPZ', '2019-04-26 03:40:43', '2019-04-26 03:40:43'),
(71, 1, 'QwUgLpMZQAN0MkWlPwMTcFfBbqjVoGql', '2019-04-26 11:57:32', '2019-04-26 11:57:32'),
(72, 1, 'C7DwQVDi0uqHn4J9UhLeHqjsS1iJ4GtZ', '2019-04-26 16:48:10', '2019-04-26 16:48:10'),
(73, 1, 'VTqrdZa8lIf8Q4s3JDhGnb3ZzQwj91n2', '2019-04-27 12:03:26', '2019-04-27 12:03:26'),
(74, 1, 'lKbVTCL8miVCuMtKTWzNzdmwLfV3GuzL', '2019-04-28 02:40:02', '2019-04-28 02:40:02'),
(75, 1, 'uuebhhpvtn6j6ifJcz4PrQGZPv3ajdlg', '2019-04-28 10:13:19', '2019-04-28 10:13:19'),
(76, 1, 'SZeFyZ4EwFF77xO9oODmjlvj2doQAus2', '2019-04-30 12:06:16', '2019-04-30 12:06:16'),
(77, 1, 'LsuogVxGe3ynGNFbpbAGqI06Nxz6aEoj', '2019-05-01 01:26:37', '2019-05-01 01:26:37'),
(78, 1, 'bCmiCYUE94wWwBfnjVYkZ9LaKOnHs9EB', '2019-05-01 15:30:00', '2019-05-01 15:30:00'),
(79, 1, 'TnyS7YRm2XERppak9TEBMHxexo2jnyVF', '2019-05-05 03:05:34', '2019-05-05 03:05:34'),
(80, 1, 'Sphez8k3CHh5nKoGEar7EbVRftAboxNd', '2019-05-05 11:15:01', '2019-05-05 11:15:01'),
(81, 1, 'nI6UErX4Our5BEfSMEEeK6niYXGOoGKR', '2019-05-05 21:30:24', '2019-05-05 21:30:24'),
(82, 1, '0mRjnZ6hbbpSbf3i033Hq1e6GDnVdmss', '2019-05-06 03:41:30', '2019-05-06 03:41:30'),
(83, 1, 'c8yc2U4omb65gdDZHuvT6jF044A51l0b', '2019-05-06 10:35:13', '2019-05-06 10:35:13'),
(84, 1, 'I8qxWADM32Zf1cZnD3WQabZlHKIv0WI5', '2019-05-07 07:02:11', '2019-05-07 07:02:11'),
(85, 1, 'jQjvBMpx1uNYBWkI5bEuWVvlNTNpL4jS', '2019-05-07 10:43:32', '2019-05-07 10:43:32'),
(86, 1, 'VvHwE3hBq9N9eg8g7C0qhYFAkmieXwMk', '2019-05-08 02:39:59', '2019-05-08 02:39:59'),
(87, 1, 'L2yv84SNCN93EvHhhkZ5ZAii88p2Qgk0', '2019-05-09 10:15:54', '2019-05-09 10:15:54'),
(88, 1, 'LCC98k8oZu28QeAWFn6xuxnaa8n5NfKv', '2019-05-10 05:02:27', '2019-05-10 05:02:27'),
(89, 1, 'wCLMmoLqiInvZnV88Od7H4ho3CSz925Y', '2019-05-10 10:09:03', '2019-05-10 10:09:03'),
(90, 1, '1dfUE4xJpaGfN91XzITDH3HBcSX4oUjz', '2019-05-10 14:39:35', '2019-05-10 14:39:35'),
(91, 1, 'akQPirKvDizL0w7ztSy3pJEdorHrUiwa', '2019-05-11 03:43:44', '2019-05-11 03:43:44'),
(92, 1, 'jz59vsBwJmfujNG7mq8AXY0a58pMucXx', '2019-05-11 22:08:18', '2019-05-11 22:08:18'),
(93, 1, 'zj7EEMJFrDHJetii2uFr89Ha28YaE10r', '2019-05-12 13:09:51', '2019-05-12 13:09:51'),
(94, 1, 'XSB1O1m4El2OqAUj92NkjM4KrFS2ksjG', '2019-05-12 23:19:35', '2019-05-12 23:19:35'),
(95, 1, 'FHeqWvAnf8AdsazFIUSEg0ijCnYawoMK', '2019-05-13 02:49:32', '2019-05-13 02:49:32'),
(96, 1, '86dJMvOA11tjSRcUdT00pk8BmsdGIyEd', '2019-05-13 10:04:36', '2019-05-13 10:04:36'),
(97, 1, 'l5kb7jDp5Hj1050I6W8FAtROLbwx6Tyl', '2019-05-13 15:13:09', '2019-05-13 15:13:09'),
(98, 1, 'xpRhAeCS5h4TEH4pFsFDe2iS4K5sXJ0C', '2019-05-13 23:41:16', '2019-05-13 23:41:16'),
(99, 1, 'jLIb1SRH3i03fOJ0pivhd0YiMvlh1qkR', '2019-05-14 11:15:31', '2019-05-14 11:15:31'),
(100, 2, 'BCMIlbDE5l9muwZQTmlrbTjhdI9KEwbw', '2019-05-14 17:20:50', '2019-05-14 17:20:50'),
(101, 1, 'xYAQF1bcbIRLI0RlAWoWZ9XGoZVBd8XM', '2019-05-15 01:21:24', '2019-05-15 01:21:24'),
(102, 1, 'pcZWOKNsHKMSNNPfmcxV0aPreEr287ZC', '2019-05-15 01:21:32', '2019-05-15 01:21:32'),
(106, 5, 'Mj0vkQaoOYXfkeWkNGELUOcOi2jjC4W8', '2019-05-15 06:11:59', '2019-05-15 06:11:59'),
(107, 2, '4W7YNGZdxSlBmjeFmARYgW44Iyx7G320', '2019-05-15 10:21:06', '2019-05-15 10:21:06'),
(109, 2, 'lBV6ZONNFcFKqUS5Hme7mrAts4pviTLM', '2019-05-15 10:59:00', '2019-05-15 10:59:00'),
(110, 2, 'kNCekVobYLccfEDpFHXPeaiNrk7fISFL', '2019-05-15 14:18:34', '2019-05-15 14:18:34'),
(111, 2, 'E3iQ5Tk3LQohjrhJernNxArp3gyrDbZk', '2019-05-16 03:49:10', '2019-05-16 03:49:10'),
(112, 2, 'qFfSo1eiPb0dXWKMlMgF2xHagFauLlIB', '2019-05-16 06:14:55', '2019-05-16 06:14:55'),
(113, 2, 'nT02DcgxNCWVQMZZypFb0yoiOnL0Vrgc', '2019-05-16 10:22:50', '2019-05-16 10:22:50'),
(114, 1, 'jtnUPHRhldX9jBgD9KUpvvZbpD3NWJTj', '2019-05-16 10:43:09', '2019-05-16 10:43:09'),
(115, 1, 'yFAEcZHk1KG1Rth62x9B5Zq4UZANHliR', '2019-05-16 11:27:07', '2019-05-16 11:27:07'),
(116, 1, 'Cg5OMqgwu3zr8QiTNC84t1SOhhWJ05iX', '2019-05-16 11:28:46', '2019-05-16 11:28:46'),
(118, 2, 'eVuzZgWnP4rNlLdQ5pUGN8HZM8EC8Ev7', '2019-05-17 05:07:16', '2019-05-17 05:07:16'),
(119, 2, 'GnHCdBcl9y91HzR1WVPsGgOXyHPg6Nb5', '2019-05-17 10:42:57', '2019-05-17 10:42:57'),
(120, 2, 'WKo34kTD4UG0RL6ecTqBmVS9lMK4yJPI', '2019-05-18 10:15:25', '2019-05-18 10:15:25'),
(123, 1, 'ohafcezAaOSegLCAPey5PgeZbjE4GVaY', '2019-05-18 15:07:19', '2019-05-18 15:07:19'),
(124, 8, 'OGAThoS0noR0UBzrpU9ki6zx5DB0JQ47', '2019-05-18 16:00:07', '2019-05-18 16:00:07'),
(125, 6, 'C060Q1ZW9Eet5oletrSwy6XrmVEqymD5', '2019-05-18 18:36:16', '2019-05-18 18:36:16'),
(126, 1, 'J6PSxEpYGoWxDc8X3opYxeAcVvhhjOlv', '2019-05-18 18:37:39', '2019-05-18 18:37:39'),
(128, 8, 'mUg1KC7SytyoSJHDfUbHD5tlrETeyf3g', '2019-05-19 03:56:46', '2019-05-19 03:56:46'),
(129, 8, 'cgVuIdfo2BgHoxGcrjXGeAGlxswpubGL', '2019-05-19 13:34:38', '2019-05-19 13:34:38'),
(130, 1, 'IJwUoYhwT9i3iadEtmchUHXUkeLXALhN', '2019-05-19 13:38:28', '2019-05-19 13:38:28'),
(131, 1, 'blWwxJjfnqpIYO2Ai8mTYZ1bJ09Ind66', '2019-05-19 18:16:54', '2019-05-19 18:16:54'),
(132, 8, 'NqaZa4mpszUDrj1YreNMhLQTWOnulvWR', '2019-05-20 04:16:20', '2019-05-20 04:16:20'),
(133, 1, 'I3iezDj1nDBnYzmRUoyaNDf09UFX2fZs', '2019-05-20 04:26:08', '2019-05-20 04:26:08'),
(135, 1, 'omjpsXUE2OAyHVCS8qGeOD6Qh6etIxze', '2019-05-20 11:17:11', '2019-05-20 11:17:11'),
(137, 2, 'q7hQpYEHSTZyeIBVY8786q7Nsj9aXRAP', '2019-05-20 13:33:10', '2019-05-20 13:33:10'),
(138, 1, 'ehSli6Op5lHqZ4dIML7u5wGtpZth5RfK', '2019-05-20 16:57:49', '2019-05-20 16:57:49'),
(141, 2, 'oRiMMvS9r2Fd9lxkM1OVW9Fy88iqfPYl', '2019-05-21 08:03:10', '2019-05-21 08:03:10'),
(142, 1, 'Hs6r18cR7lSUb3fKIMoKY4VeBvVHbp2p', '2019-05-21 14:37:37', '2019-05-21 14:37:37'),
(143, 8, 'aXe1ynXoIXmxdrTrUudvTx7Nx0EIVX6B', '2019-05-22 03:29:26', '2019-05-22 03:29:26'),
(144, 1, 'vIbivs051mXOh0NCf0tIQxs0ltqXTOmt', '2019-05-22 03:37:25', '2019-05-22 03:37:25'),
(145, 1, 'rX6rxHeUnnMUCGth9B4bhuiXBkdL1rj6', '2019-05-22 12:53:37', '2019-05-22 12:53:37'),
(146, 2, 'KW5ELq3SnqOl0mWx9VCwaWh0gGnaZB1W', '2019-05-22 12:54:16', '2019-05-22 12:54:16'),
(149, 1, '59bbMKIQP4THvjQlfTrO3EiheiiIRCLr', '2019-05-23 03:48:04', '2019-05-23 03:48:04'),
(152, 2, 'QKG6PBCv4sAyU3sgv3NyAc8U0ioiMsrp', '2019-05-23 05:07:51', '2019-05-23 05:07:51'),
(153, 1, 'IePpMHZuCM8QrX4rSSQbQoFReywINd3b', '2019-05-23 07:05:00', '2019-05-23 07:05:00'),
(154, 1, 'TR9K98l0H7laGdIEtEOfU5Od5xHbBJgR', '2019-05-23 10:44:33', '2019-05-23 10:44:33'),
(155, 2, 'FS9Jqi3sVz7cUrbD8F8NrBzkCbr8RPEI', '2019-05-23 10:45:42', '2019-05-23 10:45:42'),
(156, 2, 'mQL4j2mtzzagiLSbfjjNeSWVtrJb5AaA', '2019-05-23 14:08:19', '2019-05-23 14:08:19'),
(157, 1, 'pVZrDcCVun3mjl24TPIFF11FG2T0tEuM', '2019-05-23 14:08:43', '2019-05-23 14:08:43'),
(158, 1, 'HjX5PRbG6ErfpwKdeJmKdluJZnQz7X8v', '2019-05-26 07:20:15', '2019-05-26 07:20:15'),
(159, 1, 'SWEFo2oelRFP6x4lsNAnbnvjBMaWxoYY', '2019-05-26 10:37:16', '2019-05-26 10:37:16'),
(160, 1, '43O60TLQkkLcDqGa1Pl3QdbuOj9cdzAe', '2019-05-26 15:03:22', '2019-05-26 15:03:22'),
(161, 2, '1cPsat9oxOxwMKb2XTpXkJ8D08Nvt8Il', '2019-05-26 19:18:57', '2019-05-26 19:18:57'),
(162, 1, '4kN0X2Luqykpx1NDLPOiX056lXBD4oxv', '2019-05-27 07:02:53', '2019-05-27 07:02:53'),
(163, 1, 'naQMY7dVh4JwSl1trnVSNmvV3EDGLEZW', '2019-05-27 14:12:44', '2019-05-27 14:12:44'),
(164, 1, 'gGWf4MzQERnQUpIQZZ9E7zwFmxlIr7XV', '2019-05-28 14:13:44', '2019-05-28 14:13:44'),
(165, 1, '8cV8L3Ql5bPmHCrGJ38OzusFo6s3WtaZ', '2019-05-28 17:51:19', '2019-05-28 17:51:19'),
(166, 1, 'fDW19rjqSj0Xmra5C70cldEs3wCGQwQw', '2019-05-28 22:14:22', '2019-05-28 22:14:22'),
(167, 1, '1Pg9N4kPVTXNwSD5lhnmLNeeTzbL5xht', '2019-05-29 03:41:42', '2019-05-29 03:41:42'),
(168, 1, 'rDfbydy13rBaqGAuR3ACoilLkrwg43CQ', '2019-05-29 13:11:52', '2019-05-29 13:11:52'),
(169, 1, 'c6nMfc9Rh9gn5fhs4dqRXvPqfrDY2iYN', '2019-05-30 05:08:56', '2019-05-30 05:08:56'),
(170, 1, 'ouEOOyckIOSkahZfQ9t6wLQ8sdOfMgBA', '2019-05-30 11:10:12', '2019-05-30 11:10:12'),
(171, 1, '0gYaTR9EV8XSHeDDtxrRoVT0pv1iLqg6', '2019-05-31 11:55:03', '2019-05-31 11:55:03'),
(172, 1, 'uS5H7VLZ9oIuBLd9u621p4BWnYcRAAYi', '2019-06-01 03:24:57', '2019-06-01 03:24:57'),
(173, 1, 'bZMKcCC0eBS5aGy3UM7zK8Rhxt48uHrH', '2019-06-01 07:14:23', '2019-06-01 07:14:23'),
(174, 1, 'Cnk8Da0n939JUUAHWMZYGi2Yv6J0eux5', '2019-06-01 12:02:48', '2019-06-01 12:02:48'),
(175, 1, 'CKpvm9jjxNrDCDjWN3y61sYoKeFpR0S0', '2019-06-01 18:23:56', '2019-06-01 18:23:56'),
(176, 1, 'CwbFNogKf0ZVW1w2XD5GlKZssqXpCexm', '2019-06-02 04:21:25', '2019-06-02 04:21:25');

-- --------------------------------------------------------

--
-- Table structure for table `queues`
--

CREATE TABLE `queues` (
  `id` int(10) UNSIGNED NOT NULL,
  `bus_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `schedule_id` int(11) NOT NULL,
  `bus_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queues`
--

INSERT INTO `queues` (`id`, `bus_id`, `station_id`, `user_id`, `route_id`, `created_at`, `updated_at`, `schedule_id`, `bus_number`) VALUES
(1, 24, 1, 1, 0, '2019-05-26 19:23:03', '2019-05-26 21:13:55', 1, 'adjkj'),
(2, 13, 2, 1, 0, '2019-05-30 11:15:56', '2019-05-30 11:15:56', 3, 'busjf43r'),
(3, 23, 1, 1, 0, '2019-05-31 16:56:13', '2019-05-31 16:56:13', 1, 'jakd');

-- --------------------------------------------------------

--
-- Table structure for table `reminders`
--

CREATE TABLE `reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reminders`
--

INSERT INTO `reminders` (`id`, `user_id`, `code`, `completed`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 4, 'acSkkEUlJMDpE5pwaXYFVeRIkz8V3jmb', 1, '2019-04-07 02:12:53', '2019-04-07 02:11:28', '2019-04-07 02:12:53');

-- --------------------------------------------------------

--
-- Table structure for table `reserves`
--

CREATE TABLE `reserves` (
  `id` int(10) UNSIGNED NOT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rider_id` int(11) NOT NULL,
  `reserve_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_id` int(11) NOT NULL,
  `bus_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schedule_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reserves`
--

INSERT INTO `reserves` (`id`, `station_id`, `user_id`, `created_at`, `updated_at`, `rider_id`, `reserve_number`, `queue_id`, `bus_number`, `schedule_id`) VALUES
(5, 1, 1, '2019-05-30 14:14:23', '2019-05-30 14:14:23', 14, '', 1, 'adjkj', 1),
(7, 1, 0, '2019-06-01 19:12:48', '2019-06-01 19:12:48', 15, '', 3, 'jakd', 0),
(8, 1, 0, '2019-06-02 04:46:59', '2019-06-02 04:46:59', 16, '', 3, 'jakd', 1);

-- --------------------------------------------------------

--
-- Table structure for table `riders`
--

CREATE TABLE `riders` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `third_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ph_number` int(11) NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `station_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `riders`
--

INSERT INTO `riders` (`id`, `id_number`, `first_name`, `last_name`, `third_name`, `ph_number`, `gender`, `user_id`, `created_at`, `updated_at`, `station_id`, `bus_id`) VALUES
(14, 'Rd_03', 'adjf', 'jfka', 'ajdk', 4539804, 'male', 2, '2019-05-22 16:02:02', '2019-05-22 16:02:02', 1, 0),
(15, 'Rd_01', 'yahye', 'saleeban', 'ahmed', 4236256, 'male', 1, '2019-06-01 19:07:48', '2019-06-01 19:07:48', 0, 0),
(16, 'Rd_02', 'sicid', 'mahamed', 'muse', 4024393, 'male', 1, '2019-06-02 04:28:04', '2019-06-02 04:28:04', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `slug`, `name`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Admin', '{\"admin\":1}', '2019-04-04 10:33:07', '2019-04-04 10:33:07'),
(2, 'user', 'User', NULL, '2019-04-04 10:33:07', '2019-04-04 10:33:07');

-- --------------------------------------------------------

--
-- Table structure for table `role_users`
--

CREATE TABLE `role_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_users`
--

INSERT INTO `role_users` (`user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-04-04 10:33:07', '2019-04-04 10:33:07'),
(2, 2, '2019-04-04 10:35:06', '2019-04-04 10:35:06'),
(3, 2, '2019-04-04 10:51:27', '2019-04-04 10:51:27'),
(4, 2, '2019-04-06 13:02:30', '2019-04-06 13:02:30'),
(5, 2, '2019-04-14 03:36:42', '2019-04-14 03:36:42'),
(6, 2, '2019-04-28 03:10:32', '2019-04-28 03:10:32'),
(7, 2, '2019-05-15 05:19:42', '2019-05-15 05:19:42'),
(8, 2, '2019-05-18 15:04:53', '2019-05-18 15:04:53');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `schedule_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `route_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `created_at`, `updated_at`, `schedule_number`, `station_id`, `user_id`, `route_id`) VALUES
(1, '2019-05-26 15:21:54', '2019-05-26 15:59:47', 'Sch_sn01', 1, 1, NULL),
(3, '2019-05-26 16:11:16', '2019-05-26 16:11:16', 'Sch_jg01', 2, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id` int(10) UNSIGNED NOT NULL,
  `seat_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bus_id` int(11) NOT NULL,
  `bus_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`id`, `seat_number`, `created_at`, `updated_at`, `bus_id`, `bus_number`) VALUES
(1, 'A1', '2019-05-28 22:41:46', '2019-05-28 22:41:46', 23, 'jakd'),
(2, 'A2', '2019-05-29 09:37:18', '2019-05-29 09:37:18', 23, 'jakd');

-- --------------------------------------------------------

--
-- Table structure for table `stations`
--

CREATE TABLE `stations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` decimal(10,7) NOT NULL,
  `long` decimal(10,7) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stations`
--

INSERT INTO `stations` (`id`, `name`, `lat`, `long`, `created_at`, `updated_at`) VALUES
(1, 'siinay', '9.3422400', '45.4220000', '2019-04-23 08:43:16', '2019-04-23 08:43:16'),
(2, 'jigjiga', '34.5300000', '23.3220000', '2019-04-23 08:43:35', '2019-04-23 08:43:35'),
(3, 'Idaacada', '43.3500000', '43.5300000', '2019-04-30 13:19:20', '2019-04-30 13:19:20');

-- --------------------------------------------------------

--
-- Table structure for table `taggable_taggables`
--

CREATE TABLE `taggable_taggables` (
  `tag_id` int(10) UNSIGNED NOT NULL,
  `taggable_id` int(10) UNSIGNED NOT NULL,
  `taggable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `taggable_taggables`
--

INSERT INTO `taggable_taggables` (`tag_id`, `taggable_id`, `taggable_type`, `created_at`, `updated_at`) VALUES
(1, 1, 'App\\Blog', '2019-05-12 15:59:30', '2019-05-12 15:59:30'),
(2, 2, 'App\\Blog', '2019-05-12 16:01:47', '2019-05-12 16:01:47');

-- --------------------------------------------------------

--
-- Table structure for table `taggable_tags`
--

CREATE TABLE `taggable_tags` (
  `tag_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `taggable_tags`
--

INSERT INTO `taggable_tags` (`tag_id`, `name`, `normalized`, `created_at`, `updated_at`) VALUES
(1, 'dfakjdk', 'dfakjdk', '2019-05-12 15:59:30', '2019-05-12 15:59:30'),
(2, 'ajdkfa', 'ajdkfa', '2019-05-12 16:01:47', '2019-05-12 16:01:47');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `finished` tinyint(4) NOT NULL DEFAULT '0',
  `task_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_deadline` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `throttle`
--

CREATE TABLE `throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `throttle`
--

INSERT INTO `throttle` (`id`, `user_id`, `type`, `ip`, `created_at`, `updated_at`) VALUES
(1, NULL, 'global', NULL, '2019-04-04 10:34:29', '2019-04-04 10:34:29'),
(2, NULL, 'ip', '::1', '2019-04-04 10:34:29', '2019-04-04 10:34:29'),
(3, 1, 'user', NULL, '2019-04-04 10:34:29', '2019-04-04 10:34:29'),
(4, NULL, 'global', NULL, '2019-04-06 15:36:23', '2019-04-06 15:36:23'),
(5, NULL, 'ip', '::1', '2019-04-06 15:36:24', '2019-04-06 15:36:24'),
(6, NULL, 'global', NULL, '2019-04-06 15:36:39', '2019-04-06 15:36:39'),
(7, NULL, 'ip', '::1', '2019-04-06 15:36:39', '2019-04-06 15:36:39'),
(8, NULL, 'global', NULL, '2019-04-06 15:37:07', '2019-04-06 15:37:07'),
(9, NULL, 'ip', '::1', '2019-04-06 15:37:07', '2019-04-06 15:37:07'),
(10, 1, 'user', NULL, '2019-04-06 15:37:07', '2019-04-06 15:37:07'),
(11, NULL, 'global', NULL, '2019-04-06 15:37:14', '2019-04-06 15:37:14'),
(12, NULL, 'ip', '::1', '2019-04-06 15:37:14', '2019-04-06 15:37:14'),
(13, 1, 'user', NULL, '2019-04-06 15:37:14', '2019-04-06 15:37:14'),
(14, NULL, 'global', NULL, '2019-04-06 15:39:55', '2019-04-06 15:39:55'),
(15, NULL, 'ip', '::1', '2019-04-06 15:39:55', '2019-04-06 15:39:55'),
(16, 1, 'user', NULL, '2019-04-06 15:39:55', '2019-04-06 15:39:55'),
(17, NULL, 'global', NULL, '2019-04-06 15:46:17', '2019-04-06 15:46:17'),
(18, NULL, 'ip', '::1', '2019-04-06 15:46:17', '2019-04-06 15:46:17'),
(19, NULL, 'global', NULL, '2019-04-07 02:08:58', '2019-04-07 02:08:58'),
(20, NULL, 'ip', '::1', '2019-04-07 02:08:58', '2019-04-07 02:08:58'),
(21, 1, 'user', NULL, '2019-04-07 02:08:58', '2019-04-07 02:08:58'),
(22, NULL, 'global', NULL, '2019-04-07 02:13:05', '2019-04-07 02:13:05'),
(23, NULL, 'ip', '::1', '2019-04-07 02:13:05', '2019-04-07 02:13:05'),
(24, 4, 'user', NULL, '2019-04-07 02:13:05', '2019-04-07 02:13:05'),
(25, NULL, 'global', NULL, '2019-04-07 02:13:15', '2019-04-07 02:13:15'),
(26, NULL, 'ip', '::1', '2019-04-07 02:13:15', '2019-04-07 02:13:15'),
(27, 4, 'user', NULL, '2019-04-07 02:13:15', '2019-04-07 02:13:15'),
(28, NULL, 'global', NULL, '2019-04-08 01:32:16', '2019-04-08 01:32:16'),
(29, NULL, 'ip', '::1', '2019-04-08 01:32:16', '2019-04-08 01:32:16'),
(30, NULL, 'global', NULL, '2019-04-08 01:32:25', '2019-04-08 01:32:25'),
(31, NULL, 'ip', '::1', '2019-04-08 01:32:25', '2019-04-08 01:32:25'),
(32, NULL, 'global', NULL, '2019-04-08 16:29:02', '2019-04-08 16:29:02'),
(33, NULL, 'ip', '::1', '2019-04-08 16:29:02', '2019-04-08 16:29:02'),
(34, 1, 'user', NULL, '2019-04-08 16:29:02', '2019-04-08 16:29:02'),
(35, NULL, 'global', NULL, '2019-04-11 03:27:17', '2019-04-11 03:27:17'),
(36, NULL, 'ip', '::1', '2019-04-11 03:27:17', '2019-04-11 03:27:17'),
(37, 1, 'user', NULL, '2019-04-11 03:27:17', '2019-04-11 03:27:17'),
(38, NULL, 'global', NULL, '2019-04-11 03:27:28', '2019-04-11 03:27:28'),
(39, NULL, 'ip', '::1', '2019-04-11 03:27:28', '2019-04-11 03:27:28'),
(40, NULL, 'global', NULL, '2019-04-11 11:21:23', '2019-04-11 11:21:23'),
(41, NULL, 'ip', '::1', '2019-04-11 11:21:23', '2019-04-11 11:21:23'),
(42, 2, 'user', NULL, '2019-04-11 11:21:23', '2019-04-11 11:21:23'),
(43, NULL, 'global', NULL, '2019-04-11 11:22:00', '2019-04-11 11:22:00'),
(44, NULL, 'ip', '::1', '2019-04-11 11:22:00', '2019-04-11 11:22:00'),
(45, 1, 'user', NULL, '2019-04-11 11:22:01', '2019-04-11 11:22:01'),
(46, NULL, 'global', NULL, '2019-04-13 11:23:20', '2019-04-13 11:23:20'),
(47, NULL, 'ip', '::1', '2019-04-13 11:23:20', '2019-04-13 11:23:20'),
(48, NULL, 'global', NULL, '2019-04-14 03:17:50', '2019-04-14 03:17:50'),
(49, NULL, 'ip', '::1', '2019-04-14 03:17:50', '2019-04-14 03:17:50'),
(50, 2, 'user', NULL, '2019-04-14 03:17:50', '2019-04-14 03:17:50'),
(51, NULL, 'global', NULL, '2019-04-14 03:17:58', '2019-04-14 03:17:58'),
(52, NULL, 'ip', '::1', '2019-04-14 03:17:58', '2019-04-14 03:17:58'),
(53, 2, 'user', NULL, '2019-04-14 03:17:58', '2019-04-14 03:17:58'),
(54, NULL, 'global', NULL, '2019-04-14 03:18:22', '2019-04-14 03:18:22'),
(55, NULL, 'ip', '::1', '2019-04-14 03:18:22', '2019-04-14 03:18:22'),
(56, 2, 'user', NULL, '2019-04-14 03:18:22', '2019-04-14 03:18:22'),
(57, NULL, 'global', NULL, '2019-04-14 03:18:30', '2019-04-14 03:18:30'),
(58, NULL, 'ip', '::1', '2019-04-14 03:18:30', '2019-04-14 03:18:30'),
(59, 2, 'user', NULL, '2019-04-14 03:18:30', '2019-04-14 03:18:30'),
(60, NULL, 'global', NULL, '2019-04-14 03:19:03', '2019-04-14 03:19:03'),
(61, NULL, 'ip', '::1', '2019-04-14 03:19:03', '2019-04-14 03:19:03'),
(62, 2, 'user', NULL, '2019-04-14 03:19:03', '2019-04-14 03:19:03'),
(63, NULL, 'global', NULL, '2019-04-14 03:19:24', '2019-04-14 03:19:24'),
(64, NULL, 'ip', '::1', '2019-04-14 03:19:24', '2019-04-14 03:19:24'),
(65, 2, 'user', NULL, '2019-04-14 03:19:24', '2019-04-14 03:19:24'),
(66, NULL, 'global', NULL, '2019-04-14 03:35:50', '2019-04-14 03:35:50'),
(67, NULL, 'ip', '::1', '2019-04-14 03:35:50', '2019-04-14 03:35:50'),
(68, 2, 'user', NULL, '2019-04-14 03:35:50', '2019-04-14 03:35:50'),
(69, NULL, 'global', NULL, '2019-04-15 03:53:53', '2019-04-15 03:53:53'),
(70, NULL, 'ip', '::1', '2019-04-15 03:53:53', '2019-04-15 03:53:53'),
(71, 1, 'user', NULL, '2019-04-15 03:53:53', '2019-04-15 03:53:53'),
(72, NULL, 'global', NULL, '2019-04-17 04:35:44', '2019-04-17 04:35:44'),
(73, NULL, 'ip', '::1', '2019-04-17 04:35:44', '2019-04-17 04:35:44'),
(74, 1, 'user', NULL, '2019-04-17 04:35:44', '2019-04-17 04:35:44'),
(75, NULL, 'global', NULL, '2019-04-26 11:56:42', '2019-04-26 11:56:42'),
(76, NULL, 'ip', '::1', '2019-04-26 11:56:43', '2019-04-26 11:56:43'),
(77, NULL, 'global', NULL, '2019-04-26 11:56:55', '2019-04-26 11:56:55'),
(78, NULL, 'ip', '::1', '2019-04-26 11:56:55', '2019-04-26 11:56:55'),
(79, NULL, 'global', NULL, '2019-04-26 11:57:17', '2019-04-26 11:57:17'),
(80, NULL, 'ip', '::1', '2019-04-26 11:57:18', '2019-04-26 11:57:18'),
(81, NULL, 'global', NULL, '2019-05-05 03:05:28', '2019-05-05 03:05:28'),
(82, NULL, 'ip', '::1', '2019-05-05 03:05:28', '2019-05-05 03:05:28'),
(83, 1, 'user', NULL, '2019-05-05 03:05:28', '2019-05-05 03:05:28'),
(84, NULL, 'global', NULL, '2019-05-07 07:02:04', '2019-05-07 07:02:04'),
(85, NULL, 'ip', '::1', '2019-05-07 07:02:04', '2019-05-07 07:02:04'),
(86, 1, 'user', NULL, '2019-05-07 07:02:04', '2019-05-07 07:02:04'),
(87, NULL, 'global', NULL, '2019-05-08 02:39:47', '2019-05-08 02:39:47'),
(88, NULL, 'ip', '::1', '2019-05-08 02:39:48', '2019-05-08 02:39:48'),
(89, 1, 'user', NULL, '2019-05-08 02:39:48', '2019-05-08 02:39:48'),
(90, NULL, 'global', NULL, '2019-05-08 02:39:52', '2019-05-08 02:39:52'),
(91, NULL, 'ip', '::1', '2019-05-08 02:39:53', '2019-05-08 02:39:53'),
(92, 1, 'user', NULL, '2019-05-08 02:39:53', '2019-05-08 02:39:53'),
(93, NULL, 'global', NULL, '2019-05-10 14:37:28', '2019-05-10 14:37:28'),
(94, NULL, 'ip', '::1', '2019-05-10 14:37:28', '2019-05-10 14:37:28'),
(95, 1, 'user', NULL, '2019-05-10 14:37:28', '2019-05-10 14:37:28'),
(96, NULL, 'global', NULL, '2019-05-11 03:43:31', '2019-05-11 03:43:31'),
(97, NULL, 'ip', '::1', '2019-05-11 03:43:31', '2019-05-11 03:43:31'),
(98, 1, 'user', NULL, '2019-05-11 03:43:31', '2019-05-11 03:43:31'),
(99, NULL, 'global', NULL, '2019-05-11 22:08:07', '2019-05-11 22:08:07'),
(100, NULL, 'ip', '::1', '2019-05-11 22:08:07', '2019-05-11 22:08:07'),
(101, 1, 'user', NULL, '2019-05-11 22:08:07', '2019-05-11 22:08:07'),
(102, NULL, 'global', NULL, '2019-05-12 23:19:48', '2019-05-12 23:19:48'),
(103, NULL, 'ip', '::1', '2019-05-12 23:19:48', '2019-05-12 23:19:48'),
(104, 1, 'user', NULL, '2019-05-12 23:19:48', '2019-05-12 23:19:48'),
(105, NULL, 'global', NULL, '2019-05-15 01:36:27', '2019-05-15 01:36:27'),
(106, NULL, 'ip', '::1', '2019-05-15 01:36:27', '2019-05-15 01:36:27'),
(107, 1, 'user', NULL, '2019-05-15 01:36:27', '2019-05-15 01:36:27'),
(108, NULL, 'global', NULL, '2019-05-15 05:20:10', '2019-05-15 05:20:10'),
(109, NULL, 'ip', '::1', '2019-05-15 05:20:10', '2019-05-15 05:20:10'),
(110, NULL, 'global', NULL, '2019-05-15 05:20:26', '2019-05-15 05:20:26'),
(111, NULL, 'ip', '::1', '2019-05-15 05:20:26', '2019-05-15 05:20:26'),
(112, NULL, 'global', NULL, '2019-05-15 10:21:12', '2019-05-15 10:21:12'),
(113, NULL, 'ip', '::1', '2019-05-15 10:21:12', '2019-05-15 10:21:12'),
(114, 1, 'user', NULL, '2019-05-15 10:21:13', '2019-05-15 10:21:13'),
(115, NULL, 'global', NULL, '2019-05-17 03:50:04', '2019-05-17 03:50:04'),
(116, NULL, 'ip', '::1', '2019-05-17 03:50:04', '2019-05-17 03:50:04'),
(117, 1, 'user', NULL, '2019-05-17 03:50:04', '2019-05-17 03:50:04'),
(118, NULL, 'global', NULL, '2019-05-18 15:05:45', '2019-05-18 15:05:45'),
(119, NULL, 'ip', '::1', '2019-05-18 15:05:45', '2019-05-18 15:05:45'),
(120, 1, 'user', NULL, '2019-05-18 15:05:45', '2019-05-18 15:05:45'),
(121, NULL, 'global', NULL, '2019-05-18 15:06:01', '2019-05-18 15:06:01'),
(122, NULL, 'ip', '::1', '2019-05-18 15:06:01', '2019-05-18 15:06:01'),
(123, 1, 'user', NULL, '2019-05-18 15:06:01', '2019-05-18 15:06:01'),
(124, NULL, 'global', NULL, '2019-05-18 18:37:32', '2019-05-18 18:37:32'),
(125, NULL, 'ip', '::1', '2019-05-18 18:37:32', '2019-05-18 18:37:32'),
(126, NULL, 'global', NULL, '2019-05-20 04:25:59', '2019-05-20 04:25:59'),
(127, NULL, 'ip', '::1', '2019-05-20 04:26:00', '2019-05-20 04:26:00'),
(128, 1, 'user', NULL, '2019-05-20 04:26:00', '2019-05-20 04:26:00'),
(129, NULL, 'global', NULL, '2019-05-20 10:12:17', '2019-05-20 10:12:17'),
(130, NULL, 'ip', '::1', '2019-05-20 10:12:17', '2019-05-20 10:12:17'),
(131, NULL, 'global', NULL, '2019-05-20 16:57:34', '2019-05-20 16:57:34'),
(132, NULL, 'ip', '::1', '2019-05-20 16:57:34', '2019-05-20 16:57:34'),
(133, 1, 'user', NULL, '2019-05-20 16:57:34', '2019-05-20 16:57:34'),
(134, NULL, 'global', NULL, '2019-05-21 10:44:10', '2019-05-21 10:44:10'),
(135, NULL, 'ip', '::1', '2019-05-21 10:44:10', '2019-05-21 10:44:10'),
(136, 1, 'user', NULL, '2019-05-21 10:44:10', '2019-05-21 10:44:10'),
(137, NULL, 'global', NULL, '2019-05-22 03:27:45', '2019-05-22 03:27:45'),
(138, NULL, 'ip', '::1', '2019-05-22 03:27:45', '2019-05-22 03:27:45'),
(139, 1, 'user', NULL, '2019-05-22 03:27:45', '2019-05-22 03:27:45'),
(140, NULL, 'global', NULL, '2019-05-23 03:47:41', '2019-05-23 03:47:41'),
(141, NULL, 'ip', '::1', '2019-05-23 03:47:41', '2019-05-23 03:47:41'),
(142, 1, 'user', NULL, '2019-05-23 03:47:41', '2019-05-23 03:47:41'),
(143, NULL, 'global', NULL, '2019-05-23 05:03:03', '2019-05-23 05:03:03'),
(144, NULL, 'ip', '::1', '2019-05-23 05:03:03', '2019-05-23 05:03:03'),
(145, 1, 'user', NULL, '2019-05-23 05:03:03', '2019-05-23 05:03:03'),
(146, NULL, 'global', NULL, '2019-05-23 14:08:33', '2019-05-23 14:08:33'),
(147, NULL, 'ip', '::1', '2019-05-23 14:08:33', '2019-05-23 14:08:33'),
(148, 1, 'user', NULL, '2019-05-23 14:08:33', '2019-05-23 14:08:33'),
(149, NULL, 'global', NULL, '2019-05-23 14:08:37', '2019-05-23 14:08:37'),
(150, NULL, 'ip', '::1', '2019-05-23 14:08:37', '2019-05-23 14:08:37'),
(151, 1, 'user', NULL, '2019-05-23 14:08:37', '2019-05-23 14:08:37'),
(152, NULL, 'global', NULL, '2019-05-26 10:36:43', '2019-05-26 10:36:43'),
(153, NULL, 'ip', '::1', '2019-05-26 10:36:44', '2019-05-26 10:36:44'),
(154, 1, 'user', NULL, '2019-05-26 10:36:44', '2019-05-26 10:36:44'),
(155, NULL, 'global', NULL, '2019-05-28 22:14:04', '2019-05-28 22:14:04'),
(156, NULL, 'ip', '::1', '2019-05-28 22:14:04', '2019-05-28 22:14:04'),
(157, NULL, 'global', NULL, '2019-05-29 03:41:30', '2019-05-29 03:41:30'),
(158, NULL, 'ip', '::1', '2019-05-29 03:41:30', '2019-05-29 03:41:30'),
(159, 1, 'user', NULL, '2019-05-29 03:41:30', '2019-05-29 03:41:30'),
(160, NULL, 'global', NULL, '2019-05-29 03:41:36', '2019-05-29 03:41:36'),
(161, NULL, 'ip', '::1', '2019-05-29 03:41:36', '2019-05-29 03:41:36'),
(162, 1, 'user', NULL, '2019-05-29 03:41:36', '2019-05-29 03:41:36'),
(163, NULL, 'global', NULL, '2019-06-01 03:24:41', '2019-06-01 03:24:41'),
(164, NULL, 'ip', '::1', '2019-06-01 03:24:41', '2019-06-01 03:24:41'),
(165, 1, 'user', NULL, '2019-06-01 03:24:41', '2019-06-01 03:24:41'),
(166, NULL, 'global', NULL, '2019-06-01 03:24:51', '2019-06-01 03:24:51'),
(167, NULL, 'ip', '::1', '2019-06-01 03:24:51', '2019-06-01 03:24:51'),
(168, 1, 'user', NULL, '2019-06-01 03:24:52', '2019-06-01 03:24:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `last_login` timestamp NULL DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `station_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `permissions`, `last_login`, `first_name`, `last_name`, `created_at`, `updated_at`, `deleted_at`, `bio`, `gender`, `dob`, `pic`, `country`, `state`, `city`, `address`, `postal`, `station_id`) VALUES
(1, 'admin@admin.com', '$2y$10$GoTAMvndBMZskduhOcPNpeqy5rQKwU9EEYy/9dDsiH8k6o7b0P8a6', NULL, '2019-06-02 04:21:25', 'John', 'Doe', '2019-04-04 10:33:06', '2019-06-02 04:21:25', NULL, NULL, NULL, NULL, 'WQnrlk5hXR.jpeg', NULL, NULL, NULL, NULL, NULL, 0),
(2, 'abokorhassan@gmail.com', '$2y$10$YmemNYiUBVdrbiS.L8jvh.Hyea5epAHs/O11G7jjPDQOAK5WKGeay', NULL, '2019-05-26 19:18:57', 'abokor', 'Elmis', '2019-04-04 10:35:06', '2019-05-26 19:18:57', NULL, NULL, 'male', '2019-04-29', NULL, NULL, NULL, NULL, NULL, NULL, 1),
(3, 'raazi@gmail.com', '$2y$10$7.pPcWpESctnda3Tk8YXrepvSD1aJbM29vQCmw0ugJFSyTZ40/KHS', NULL, NULL, 'raazi', 'hassan', '2019-04-04 10:51:27', '2019-04-06 13:11:35', '2019-04-06 13:11:35', NULL, 'male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(4, 'xofelezu@pachilly.com', '$2y$10$Qel6pOF.5oC6ku/f1QG13.UjaLyCo1it6AGyNNLBBE7ximWsv3BZ.', NULL, '2019-04-07 02:13:23', 'Robert', 'Hamilton', '2019-04-06 13:02:30', '2019-04-14 00:34:57', '2019-04-14 00:34:57', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, 'kaambulkaambul@gmail.com', '$2y$10$PYFb1AksdMOwFav0ajwgaeGPBHuTnZ1LOfrhopzgXuYy.Mz.Zoc3e', NULL, '2019-05-15 06:11:59', 'kaambul', 'yusuf', '2019-04-14 03:36:41', '2019-05-15 06:11:59', NULL, NULL, 'male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3),
(6, 'yusuf@gmail.com', '$2y$10$u045.s6MbZaYN2CBdY2uPOFiHWnipCuhXHR00NzqycDbaOptTyagm', NULL, '2019-05-18 18:36:16', 'yusuf', 'cabdi', '2019-04-28 03:10:32', '2019-05-18 18:36:16', NULL, NULL, 'male', '2019-04-10', 'FpiL9yyAd7.jpeg', NULL, NULL, NULL, 'Axmed dhagax', NULL, 2),
(7, 'yahye@gmai.com', '$2y$10$1lB0QXGXcubfqaXfnqlSf.Z8ZRUYiKT4uPxfWq2wvqIGaNws5IPFi', NULL, '2019-05-15 05:36:41', 'yahye', 'hassan', '2019-05-15 05:19:42', '2019-05-15 05:38:37', NULL, NULL, 'male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(8, 'nair@gmail.com', '$2y$10$OB4jxdJb206p5Rw9tj1MJe56xWxjldqsmgUzDpOwkjgnDFtNoOYG6', NULL, '2019-05-22 03:29:26', 'nasir', 'nimcan', '2019-05-18 15:04:53', '2019-05-22 03:29:26', NULL, NULL, 'male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accidents`
--
ALTER TABLE `accidents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activations`
--
ALTER TABLE `activations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activity_log_log_name_index` (`log_name`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `buses_bus_number_unique` (`bus_number`);

--
-- Indexes for table `busstops`
--
ALTER TABLE `busstops`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `busstops_bstop_num_unique` (`bstop_num`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datatables`
--
ALTER TABLE `datatables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `drivers_email_unique` (`email`),
  ADD UNIQUE KEY `drivers_ph_number_unique` (`ph_number`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `persistences`
--
ALTER TABLE `persistences`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `persistences_code_unique` (`code`);

--
-- Indexes for table `queues`
--
ALTER TABLE `queues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reminders`
--
ALTER TABLE `reminders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reserves`
--
ALTER TABLE `reserves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `riders`
--
ALTER TABLE `riders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `riders_id_number_unique` (`id_number`),
  ADD UNIQUE KEY `riders_ph_number_unique` (`ph_number`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `role_users`
--
ALTER TABLE `role_users`
  ADD PRIMARY KEY (`user_id`,`role_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `schedules_schedule_number_unique` (`schedule_number`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stations`
--
ALTER TABLE `stations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taggable_taggables`
--
ALTER TABLE `taggable_taggables`
  ADD KEY `i_taggable_fwd` (`tag_id`,`taggable_id`),
  ADD KEY `i_taggable_rev` (`taggable_id`,`tag_id`),
  ADD KEY `i_taggable_type` (`taggable_type`);

--
-- Indexes for table `taggable_tags`
--
ALTER TABLE `taggable_tags`
  ADD PRIMARY KEY (`tag_id`),
  ADD KEY `taggable_tags_normalized_index` (`normalized`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tests_email_unique` (`email`);

--
-- Indexes for table `throttle`
--
ALTER TABLE `throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `throttle_user_id_index` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accidents`
--
ALTER TABLE `accidents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `activations`
--
ALTER TABLE `activations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `buses`
--
ALTER TABLE `buses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `busstops`
--
ALTER TABLE `busstops`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `datatables`
--
ALTER TABLE `datatables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `persistences`
--
ALTER TABLE `persistences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;

--
-- AUTO_INCREMENT for table `queues`
--
ALTER TABLE `queues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reminders`
--
ALTER TABLE `reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reserves`
--
ALTER TABLE `reserves`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `riders`
--
ALTER TABLE `riders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stations`
--
ALTER TABLE `stations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `taggable_tags`
--
ALTER TABLE `taggable_tags`
  MODIFY `tag_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `throttle`
--
ALTER TABLE `throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
